import styled from "styled-components"


export const Logo = styled.a`
    color: #ccc;
    :hover{
        color: #ccc;
    }
`