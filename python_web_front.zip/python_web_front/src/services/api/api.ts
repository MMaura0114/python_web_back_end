import { URL } from "../../const"
import axios from "axios"

const token = localStorage.getItem("accessToken");
const headers: Record<string, string> = {
    "Content-Type": "application/json",
};
if (token) {
    headers["token"] = `${token}`;
}


export const api = axios.create({

    baseURL: URL,
    headers
})