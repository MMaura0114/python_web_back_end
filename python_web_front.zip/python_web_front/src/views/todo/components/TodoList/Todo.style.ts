import styled from "styled-components";

export const Tabela = styled.tr`
    justify-content: space-between;
    .markAsDone{
        text-decoration: line-through;
        color: #777
    }
   


`